@org.junit.jupiter.api.Test
void ${NAME}() {
  ${BODY}
  // Create the test parameters
  
  // Call the test method
  
  // Make sure the result is correct

}